package level_up

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LevelUpApplicationTests {

	@Test
	fun contextLoads() {
	}

}
